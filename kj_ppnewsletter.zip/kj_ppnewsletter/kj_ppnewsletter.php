<?php
if (!defined('_PS_VERSION_')) {
    exit;
}
class Kj_Ppnewsletter extends Module
{
    public function __construct() {
        $this->name = 'kj_ppnewsletter';
        $this->author = 'Jing';
        $this->version = '1.0.0';
        $this->need_instance= 0;
        $this->bootstrap = true;
        $this->tab = 'others';
        parent::__construct();
        $this->ps_versions_compliancy = array(
            'min' => '1.7',
            'max' => _PS_VERSION_
        );
        $this->displayName = $this->l('Newsletter Popup box');
        $this->description = $this->l('Displays a newsletter popup in your store');
        $this->templateFile ='module:kj_ppnewsletter/popupbox.tpl';
        $this->_html = '';
    }

    public function install(){
        if (parent::install()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayFooter')
            && $this->registerHook('actionObjectLanguageAddAfter')
            && $this->installFixtures()
        ) {
            return true;
        }
        return false;
    }
    public function uninstall(){
        if (!parent::uninstall())
            return false;
        return true;
    }
    public function hookActionObjectLanguageAddAfter($params)
    {
        return $this->installFixture((int)$params['object']->id, Configuration::get('popupbox_image', (int)Configuration::get('PS_LANG_DEFAULT')));
    }

    protected function installFixtures()
    {
        $languages = Language::getLanguages(false);

        foreach ($languages as $lang) {
            $this->installFixture((int)$lang['id_lang'], 'K&J_popup_mai20X2.png');
        }

        return true;
    }

    protected function installFixture($id_lang, $image = null)
    {
        $values['popupbox_image'][(int)$id_lang] = $image;
        $values['popupbox_data'][(int)$id_lang] = "<h3>Newsltter</h3><p>Welcome</p>";
        $values['popupbox_image_desc'][(int)$id_lang] = 'popup image';
        $values['popupbox_delay'][(int)$id_lang] = '2000';
        $values['popupbox_cookie_expire'][(int)$id_lang] = '3';

        Configuration::updateValue('popupbox_image', $values['popupbox_image']);
        Configuration::updateValue('popupbox_data', $values['popupbox_data'],true);
        Configuration::updateValue('popupbox_image_desc', $values['popupbox_image_desc']);
        Configuration::updateValue('popupbox_delay', $values['popupbox_delay']);
        Configuration::updateValue('popupbox_cookie_expire', $values['popupbox_cookie_expire']);
    }
    public function hookdisplayHeader($params)
    {
        $this->context->controller->registerJavascript('modules-ppnewsletterjs', 'modules/'.$this->name.'/views/js/popnewsletter.js',[
            'position' => 'bottom',
            'priority' => 150,
        ]);
        if($this->context->customer!=null){
            //var_dump(Configuration::get('popupbox_delay', $this->context->language->id));die;
            $isSubscribed=  $this->context->customer->newsletter;
            Media::addJsDef(['datapopup'=>array(
                'isLogged'=>$isSubscribed,
                'delay'=>Configuration::get('popupbox_delay', $this->context->language->id),
                'cookie_expire'=>Configuration::get('popupbox_cookie_expire', $this->context->language->id),
//                'navigation_begin'=>Context::getContext()->cookie->getSession()->
            )
            ]);
        }

        $this->context->controller->registerStylesheet('modules-ppnewslettercss', 'modules/'.$this->name.'/views/css/popnewsletter.css',[
            'media' => 'all',
            'priority' => 150,
        ]);
    }


    function hookDisplayFooter($params){
        if ($this->context->customer->newsletter == 1)
            return null;
        $imgname = Configuration::get('popupbox_image', $this->context->language->id);

        if ($imgname && file_exists(_PS_MODULE_DIR_.$this->name.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.$imgname)) {
            $this->smarty->assign('popupbox_image', $this->context->link->protocol_content . Tools::getMediaServer($imgname) . $this->_path . 'img/' . $imgname);
        }
        $variables = [];
        $variables['msg'] = '';
        $variables['nw_error'] = false;
        $this->context->smarty->assign('popupbox_data', Configuration::get('popupbox_data', $this->context->language->id));
        $this->context->smarty->assign('popupbox_image_desc', Configuration::get('popupbox_image_desc', $this->context->language->id));
        $this->context->smarty->assign($variables);
        return $this->display(__FILE__, '/views/templates/front/popupbox.tpl');
    }


    public function postProcess(){
        if(Tools::isSubmit('submitStoreConf')) {
            $languages = Language::getLanguages(false);
            $values = array();
            $update_images_values = false;
            foreach ($languages as $lang) {
                if (isset($_FILES['popupbox_image_'.$lang['id_lang']])
                    && isset($_FILES['popupbox_image_'.$lang['id_lang']]['tmp_name'])
                    && !empty($_FILES['popupbox_image_'.$lang['id_lang']]['tmp_name'])) {
                    if ($error = ImageManager::validateUpload($_FILES['popupbox_image_'.$lang['id_lang']], 4000000)) {
                        return $error;
                    } else {
                        $ext = substr($_FILES['popupbox_image_'.$lang['id_lang']]['name'], strrpos($_FILES['popupbox_image_'.$lang['id_lang']]['name'], '.') + 1);
                        $file_name = md5($_FILES['popupbox_image_'.$lang['id_lang']]['name']).'.'.$ext;

                        if (!move_uploaded_file($_FILES['popupbox_image_'.$lang['id_lang']]['tmp_name'], dirname(__FILE__).DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.$file_name)) {
                            return $this->displayError($this->trans('An error occurred while attempting to upload the file.', array(), 'Admin.Notifications.Error'));
                        } else {
                            if (Configuration::hasContext('popupbox_image', $lang['id_lang'], Shop::getContext())
                                && Configuration::get('popupbox_image', $lang['id_lang']) != $file_name) {
                                @unlink(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . Configuration::get('popupbox_image', $lang['id_lang']));
                            }

                            $values['popupbox_image'][$lang['id_lang']] = $file_name;
                        }
                    }

                    $update_images_values = true;
                }

                $values['popupbox_data'][$lang['id_lang']] = Tools::getValue('popupbox_data_'.$lang['id_lang']);
                $values['popupbox_image_desc'][$lang['id_lang']] = Tools::getValue('popupbox_image_desc_'.$lang['id_lang']);
                $values['popupbox_delay'][$lang['id_lang']] = Tools::getValue('popupbox_delay_'.$lang['id_lang']);
                $values['popupbox_cookie_expire'][$lang['id_lang']] = Tools::getValue('popupbox_cookie_expire_'.$lang['id_lang']);

            }
            if ($update_images_values) {
                Configuration::updateValue('popupbox_image', $values['popupbox_image']);
            }
            Configuration::updateValue('popupbox_data', $values['popupbox_data'],true);
            Configuration::updateValue('popupbox_image_desc', $values['popupbox_image_desc']);
            Configuration::updateValue('popupbox_delay', $values['popupbox_delay']);
            Configuration::updateValue('popupbox_cookie_expire', $values['popupbox_cookie_expire']);
            $this->_clearCache($this->templateFile);
            return $this->displayConfirmation($this->trans('The settings have been updated.', array(), 'Admin.Notifications.Success'));
        }
        return '';


    }

    public function getContent()
    {
        return $this->postProcess().$this->_displayForm();
    }

    public function getConfigFieldsValues()
    {
        $languages = Language::getLanguages(false);
        $fields = array();

        foreach ($languages as $lang) {
            $fields['popupbox_image'][$lang['id_lang']] = Tools::getValue('popupbox_image_'.$lang['id_lang'], Configuration::get('popupbox_image', $lang['id_lang']));
            $fields['popupbox_data'][$lang['id_lang']] = Tools::getValue('popupbox_data_'.$lang['id_lang'], Configuration::get('popupbox_data', $lang['id_lang']));
            $fields['popupbox_image_desc'][$lang['id_lang']] = Tools::getValue('popupbox_image_desc_'.$lang['id_lang'], Configuration::get('popupbox_image_desc', $lang['id_lang']));
            $fields['popupbox_delay'][$lang['id_lang']] = Tools::getValue('popupbox_delay_'.$lang['id_lang'], Configuration::get('popupbox_delay', $lang['id_lang']));
            $fields['popupbox_cookie_expire'][$lang['id_lang']] = Tools::getValue('popupbox_cookie_expire_'.$lang['id_lang'], Configuration::get('popupbox_cookie_expire', $lang['id_lang']));
        }
//var_dump($fields);die;
        return $fields;
    }

    private function _displayForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'file_lang',
                        'label' => $this->trans('popup image', array(), 'Modules.Banner.Admin'),
                        'name' => 'popupbox_image',
                        'desc' => $this->trans('Upload an image for your popup inscription. The recommended dimensions are 1110 x 214px if you are using the default theme.', array(), 'Modules.Banner.Admin'),
                        'lang' => true,
                    ),
                    array(
                        'type' => 'text',
                        'lang' => true,
                        'label' => $this->trans('popup image description', array(), 'Modules.Banner.Admin'),
                        'name' => 'popupbox_image_desc',
                        'desc' => $this->trans('Please enter a short but meaningful description for the image popup.', array(), 'Modules.Banner.Admin')
                    ),
                    array(
                        'type' => 'textarea',
                        'lang' => true,
                        'label' => $this->l('Popup texte'),
                        'name' => 'popupbox_data',
                        'desc' => $this->l(''),'class' => 'rte',
                        'autoload_rte' => true
                    ),
                    array(
                        'type' => 'text',
                        'lang' => true,
                        'label' => $this->l('Popup delay milliseconds'),
                        'name' => 'popupbox_delay',
                        'desc' => $this->trans('Please enter time of delay.', array(), 'Modules.Banner.Admin')
                    ),
                    array(
                        'type' => 'text',
                        'lang' => true,
                        'label' => $this->l('Popup cookies expire days'),
                        'name' => 'popupbox_cookie_expire',
                        'desc' => $this->trans('Please enter expire cookies days.', array(), 'Modules.Banner.Admin')
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save')
                )
            ),
        );
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->default_form_language = $lang->id;
        $helper->module = $this;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitStoreConf';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'uri' => $this->getPathUri(),
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }


}
